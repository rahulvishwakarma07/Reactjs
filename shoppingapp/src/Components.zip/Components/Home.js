    import '../App.css'
    import logo from '../Components/logo512.png'
    import banner from '../Components/Brown and Beige Illustrative Happy Birthday Banner.png'
    import axios from 'axios'
    import { useEffect, useState } from 'react';
    import Product from './Product' 
    

    export default function Home() {
            const [productList,setProductList] = useState([])
            const productUrl = "http://localhost:3000/product/view"
            useEffect(()=>{
                axios.get(productUrl).then(response=>{
                    setProductList(response.data.productlist)
                        // console.log(response.data.productlist);
                }).catch(err=>{
                    console.log("Heelo");
                    console.log(err);
                })
            },[])


        return <>
            <div className='container-fluid p-3 text-white header'>
                <header className='row'>
                    <div className='col-md-3' id='logo'>
                        <img src={logo} width={100} height={80} alt='no image' />
                        <h3>React <br /> Application</h3>
                    </div>
                    <div className='col-md-6 p-3' id='search'>
                        <input placeholder='Search' />
                    </div>
                    <div className='col-md-3 p-3 ' id='option' >
                        <span >View Cart</span>
                        <span >SignOut</span>
                    </div>
                </header>
            </div>
            {/* <div className='container-fluid p-0'>
                <img src={banner} width='100%' height='90%' />
            </div> */}

                <Product productList={productList}/>
        </>
    }

