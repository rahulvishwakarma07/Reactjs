import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

export default function SignIn() {
    const [email,setemail] = useState("")
    const [password,setpassword] = useState("")

    const signinURL = 'http://localhost:3000/user/signin'
    useEffect(()=>{
        axios.post(signinURL,{email,password})
        .then(response=>{
            console.log("SignIn Success...");
        })
        .catch(err=>{
            console.log("SignIn Failed...");
        })
    },[])

    return <>
        <div className="container-fluid bg-danger d-flex justify-content-center align-items-center" id="signup">
            <div className="form">
                <div className="text-center title">Welcome</div>
                <div className="fs-4 text-center subtitle">Login-Page</div>

                <div className="mt-4 input-container ic2">
                    <input onChange={(event)=>setemail(event.target.value)} placeholder="" type="email" className="input" id="lastname" />
                    <div className="cut"></div>
                    <label className="iLabel" for="lastname">Email</label>
                </div>
                <div className="mt-4 input-container ic2">
                    <input onChange={(event)=>setpassword(event.target.value)} placeholder="" type="password" className="input" id="email" />
                    <div className="cut cut-short"></div>
                    <label className="iLabel" for="email">Password</label>
                </div>
                <button className="mb-4 submit" type="text">SignIn</button>
                <span className="ms-5 text-center text-white" id="account">Create an account ? </span><Link className="" to="/">Signup</Link>
            </div>
        </div>
    </>
}
