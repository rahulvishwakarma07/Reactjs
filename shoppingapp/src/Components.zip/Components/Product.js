export default function Product(props) {
    const { productList } = props
    return <>
        <div className="container mt-3">
            <div className="row">
                {productList.map((product, index) => <div className="col-md-4 p-3" key={index}>
                    <div className="d-flex flex-column align-items-center" style={{ height: "430px", boxShadow: '0 0 5px grey' }}>
                        <img src={product.thumbnail} style={{ height: "250px", width: '100%' }} />
                        <h4 className="text-center mt-2">{product.title.slice(0, 24)}</h4>
                        <p className="mt-2 mb-2 text-center">Price : <b className="text-success">{product.price} Rs.</b></p>
                        <small className="text-primary" id="view">View more</small>
                        <button style={{ width: "90%" }} className="btn btn-secondary text-white mt-3">Add To Cart</button>
                    </div>
                </div>)}
            </div>
        </div>
    </>
}